import importlib.util
import json
import os
import sys
from pathlib import Path

try:
    from langchain_core.tools import tool  # Đổi sang thư viện @tool tương ứng nếu project dùng FastMCP hoặc CrewAI
except ModuleNotFoundError:
    def tool(*args, **kwargs):
        """Fallback decorator when langchain-core is not installed."""
        if args and callable(args[0]) and len(args) == 1 and not kwargs:
            return args[0]

        def decorator(func):
            return func

        return decorator

# 1. Trỏ đường dẫn về thư mục gốc của Project và thư mục demo/
# Từ: src/legal_agent/mcp/servers/graph_server.py -> lùi 4 cấp là về thư mục gốc (ROOT_DIR)
ROOT_DIR = Path(__file__).resolve().parents[4]
DEMO_DIR = ROOT_DIR / "demo"

# Thêm cả thư mục gốc và thư mục demo vào sys.path để Python giải quyết module.
for path in (ROOT_DIR, DEMO_DIR):
    path_str = str(path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)


def _load_demo_module(module_name: str, module_path: Path):
    """Load a module directly from the demo folder without unresolved static imports."""
    if not module_path.exists():
        raise FileNotFoundError(f"Không tìm thấy module {module_name} tại {module_path}")

    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Không thể tạo spec cho module {module_name} tại {module_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


# 2. Import trực tiếp LegalKG và GraphRetriever từ demo/
kg_module = _load_demo_module("kg_engine", DEMO_DIR / "kg_engine.py")
retriever_module = _load_demo_module("retriever", DEMO_DIR / "retriever.py")
LegalKG = kg_module.LegalKG
GraphRetriever = retriever_module.GraphRetriever

# 3. Khởi tạo Knowledge Graph đúng đường dẫn: data/json/legal_knowledge_graph.json
KG_JSON_PATH = ROOT_DIR / "data" / "json" / "legal_knowledge_graph.json"
KG_JSON_DIR = KG_JSON_PATH.parent
KG_JSON_DIR.mkdir(parents=True, exist_ok=True)

if not KG_JSON_PATH.exists():
    KG_JSON_PATH.write_text(
        json.dumps(
            {
                "documents": [],
                "semantic_nodes": [],
                "semantic_relationships": []
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

kg_instance = None
retriever = None

try:
    kg_instance = LegalKG(str(KG_JSON_PATH))
    retriever = GraphRetriever(kg_instance)
except Exception as e:
    raise RuntimeError(f"Không thể nạp Knowledge Graph tại {KG_JSON_PATH}: {e}")


# =====================================================================
# CÔNG CỤ CHO AGENT A: TRA CỨU ĐIỀU LUẬT GỐC (STRUCTURAL NODES)
# =====================================================================
@tool("Tìm kiếm Điều luật gốc")
def search_base_law_tool(query: str) -> str:
    """
    Tìm kiếm điều luật gốc liên quan đến câu hỏi từ đồ thị tri thức.
    Trả về mã thực thể (entity_id), mã điều luật (VD: Dieu_188) và toàn văn nội dung điều luật.
    Dành cho Agent A.
    """
    if retriever is None:
        return f"Knowledge graph chưa được khởi tạo. Thiếu tệp dữ liệu tại '{KG_JSON_PATH}'."

    entities = retriever.search_legal_entity(query)
    
    # Nếu tìm thấy thực thể ngữ nghĩa (LegalAction, LegalConcept, LegalProcedure)
    if entities:
        output = []
        for ent in entities:
            ent_id = ent["id"]
            ent_name = ent["name_vi"]
            ent_type = ent["type"]
            
            # Lấy danh sách các Điều/Khoản luật gốc (Structural Nodes) đang REGULATES thực thể này
            _, _, structural_contents = retriever.get_reasoning_path(ent_id)
            
            output.append(f"[*] Thực thể phát hiện: {ent_name} (Mã thực thể: `{ent_id}` | Loại: {ent_type})")
            if structural_contents:
                for sc in structural_contents:
                    output.append(f"    -> Mã Điều/Khoản gốc: `{sc['id']}`\n    -> Nội dung luật: {sc['text']}")
            else:
                output.append("    -> (Chưa gắn trực tiếp mã Điều/Khoản gốc trên cạnh REGULATES)")
        return "\n\n".join(output)

    # Fallback: Quét trực tiếp từ khóa trong các node Điều/Khoản (articles/clauses) nếu không khớp tên thực thể
    norm_query = retriever._normalize(query)
    matched_articles = []
    for node_id, node in retriever.nodes.items():
        if node.get("type") in ["LegalAction", "LegalConcept", "LegalProcedure"]:
            continue
        name = node.get("name", "")
        title = node.get("title", "")
        content = node.get("content", "")
        
        if norm_query in retriever._normalize(f"{name} {title} {content}") and (content or title):
            matched_articles.append(f"- Mã Điều/Khoản: `{node_id}` ({name}: {title})\n  Nội dung: {content}")

    if matched_articles:
        return "Các Điều/Khoản luật gốc tìm thấy:\n" + "\n\n".join(matched_articles[:5])

    return f"Không tìm thấy điều luật gốc hay thực thể pháp lý nào cho truy vấn: '{query}'."


# =====================================================================
# CÔNG CỤ CHO AGENT B: TRA CỨU ĐIỀU KIỆN & THỦ TỤC HƯỚNG DẪN
# =====================================================================
@tool("Tra cứu Điều kiện và Thủ tục hướng dẫn")
def get_guiding_procedures_tool(identifier: str) -> str:
    """
    Từ mã thực thể pháp lý (entity_id), mã điều luật (VD: Dieu_188) hoặc câu hỏi,
    truy xuất chuỗi suy luận đồ thị (Reasoning Paths) gồm các Điều kiện (HAS_CONDITION) 
    và Thủ tục hướng dẫn (HAS_PROCEDURE). Dành cho Agent B.
    """
    if retriever is None:
        return f"Knowledge graph chưa được khởi tạo. Thiếu tệp dữ liệu tại '{KG_JSON_PATH}'."

    target_entity_ids = []

    # Trường hợp 1: identifier truyền vào chính là ID của Semantic Node
    if identifier in retriever.nodes and retriever.nodes[identifier].get("type") in ["LegalAction", "LegalConcept", "LegalProcedure"]:
        target_entity_ids.append(identifier)
    
    # Trường hợp 2: identifier truyền vào là mã Điều/Khoản luật gốc (VD: Dieu_188)
    elif identifier in retriever.graph:
        for _, tgt, edge_data in retriever.graph.out_edges(identifier, data=True):
            if edge_data.get("relation") == "REGULATES":
                target_entity_ids.append(tgt)
                
    # Trường hợp 3: identifier là từ khóa tiếng Việt -> gọi search_legal_entity
    if not target_entity_ids:
        entities = retriever.search_legal_entity(identifier)
        target_entity_ids = [e["id"] for e in entities]

    if not target_entity_ids:
        return f"Không tìm thấy nhánh Điều kiện (HAS_CONDITION) hay Thủ tục (HAS_PROCEDURE) nào cho '{identifier}'."

    output = []
    for ent_id in target_entity_ids:
        paths, evidence_list, _ = retriever.get_reasoning_path(ent_id)
        ent_name = retriever.nodes.get(ent_id, {}).get("name_vi", ent_id)
        
        output.append(f"=== CHUỖI SUY LUẬN ĐIỀU KIỆN & THỦ TỤC CHO: {ent_name} (`{ent_id}`) ===")
        if paths:
            output.append("Sơ đồ liên kết (Graph Paths):")
            for p in paths:
                output.append(f"  • {p}")
        
        if evidence_list:
            output.append("\nChi tiết quy định hướng dẫn:")
            for ev in evidence_list:
                tgt_name = ev["target_node"].get("name_vi", ev["target_node"].get("id", ""))
                output.append(
                    f"  - [{ev['relation']}] {tgt_name}\n"
                    f"    + Nội dung trích dẫn: {ev['evidence_text']}\n"
                    f"    + Nguồn tham chiếu: {ev['source_reference']}"
                )
    return "\n\n".join(output)


# =====================================================================
# CÔNG CỤ CHO AGENT C: ĐỐI CHIẾU BẰNG CHỨNG & THAM CHIẾU PHÁP LÝ
# =====================================================================
@tool("Tra cứu Bằng chứng và Tham chiếu pháp lý")
def get_legal_evidence_tool(identifier: str) -> str:
    """
    Trích xuất danh sách bằng chứng (evidence_list), căn cứ tham chiếu (source_reference)
    và độ tin cậy (confidence) để kiểm chứng và tổng hợp câu trả lời. Dành cho Agent C.
    """
    if retriever is None:
        return f"Knowledge graph chưa được khởi tạo. Thiếu tệp dữ liệu tại '{KG_JSON_PATH}'."

    entities = retriever.search_legal_entity(identifier)
    target_id = identifier if identifier in retriever.nodes else (entities[0]["id"] if entities else None)

    if not target_id:
        return f"Không tìm thấy dữ liệu bằng chứng cho '{identifier}'."

    _, evidence_list, structural_contents = retriever.get_reasoning_path(target_id)
    
    output = [f"=== HỒ SƠ BẰNG CHỨNG & CĂN CỨ PHÁP LÝ (`{target_id}`) ==="]
    
    if structural_contents:
        output.append("1. Văn bản Điều/Khoản gốc:")
        for sc in structural_contents:
            output.append(f"   - [{sc['id']}]: {sc['text']}")

    if evidence_list:
        output.append("\n2. Dẫn chứng cụ thể trên từng điều kiện/thủ tục (Evidence List):")
        for idx, ev in enumerate(evidence_list, 1):
            output.append(
                f"   [{idx}] Quan hệ: {ev['relation']} -> {ev['target_node'].get('name_vi', '')}\n"
                f"       - Bằng chứng (Evidence): \"{ev['evidence_text']}\"\n"
                f"       - Nguồn (Source Ref): {ev['source_reference']}"
            )
    else:
        output.append("Không có dẫn chứng chi tiết nào được ghi nhận.")

    return "\n".join(output)