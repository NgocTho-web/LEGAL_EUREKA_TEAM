from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # Chế độ chạy: "ollama" hoặc "openai"
    LLM_PROVIDER: str = "ollama" 
    
    # Cấu hình Ollama (Local)
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL_NAME: str = "qwen2.5:7b" # Khuyên dùng Qwen2.5 hoặc Llama3.1 vì hỗ trợ tiếng Việt và gọi Tool tốt
    OLLAMA_EMBEDDING_MODEL: str = "nomic-embed-text"
    OLLAMA_EMBEDDING_DIM: int = 768

    # Cấu hình OpenAI (Dùng khi chuyển sang GPT)
    OPENAI_API_KEY: str = "sk-proj-xxxx"
    OPENAI_MODEL_NAME: str = "gpt-4o"
    OPENAI_EMBEDDING_MODEL: str = "text-embedding-3-large"
    OPENAI_EMBEDDING_DIM: int = 1536

    # Cấu hình Qdrant & Neo4j (Khớp với docker-compose.phase1.yml của bạn)
    QDRANT_HOST: str = "localhost"
    QDRANT_PORT: int = 6333
    QDRANT_COLLECTION_NAME: str = "vietnamese_legal_chunks"

    NEO4J_URI: str = "bolt://localhost:7688" # Lưu ý: Cổng 7688 theo file docker của bạn
    NEO4J_USER: str = "neo4j"
    NEO4J_PASSWORD: str = "password"

    class Config:
        env_file = ".env"

settings = Settings()