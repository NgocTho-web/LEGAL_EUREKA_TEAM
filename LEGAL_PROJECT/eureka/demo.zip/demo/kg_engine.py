import json
import networkx as nx

class LegalKG:
    def __init__(self, path):
        with open(path, "r", encoding="utf-8") as f:
            self.data = json.load(f)

        self.graph = nx.MultiDiGraph()
        self.nodes = {}

        # ==========================
        # 1. Load structural nodes
        # ==========================
        for doc in self.data.get("documents", []):
            self._extract_node(doc)

        # ==========================
        # 2. Load semantic nodes
        # ==========================
        for node in self.data.get("semantic_nodes", []):
            self._extract_node(node)

        # ==========================
        # 3. Load relationships
        # ==========================
        for rel in self.data.get("semantic_relationships", []):
            self.graph.add_edge(
                rel["source"],
                rel["target"],
                relation=rel["relation"],
                evidence=rel.get("evidence"),
                source_reference=rel.get("source_reference"),
                confidence=rel.get("confidence")
            )

    def _extract_node(self, node):
        if "id" in node:
            self.nodes[node["id"]] = node
            self.graph.add_node(node["id"], **node)

        # recursive children
        for key in ["chapters", "articles", "clauses", "points"]:
            for child in node.get(key, []):
                self._extract_node(child)