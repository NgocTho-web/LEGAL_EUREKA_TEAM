import unicodedata
import string

class GraphRetriever:
    def __init__(self, kg):
        self.kg = kg
        self.graph = kg.graph
        self.nodes = kg.nodes

    def _normalize(self, text):
        if not text:
            return ""
        text = str(text).lower()
        text = unicodedata.normalize('NFC', text)
        for p in string.punctuation:
            text = text.replace(p, '')
        return text.strip()

    def search_legal_entity(self, query):
        results = []
        norm_query = self._normalize(query)
        
        for node_id, node in self.nodes.items():
            node_type = node.get("type", "")
            if node_type not in ["LegalAction", "LegalConcept", "LegalProcedure"]:
                continue
                
            name_vi = node.get("name_vi", "")
            norm_name = self._normalize(name_vi)
            
            if norm_query in norm_name or norm_name in norm_query:
                results.append({
                    "id": node_id,
                    "name_vi": name_vi,
                    "type": node_type
                })
        
        return results

    def get_reasoning_path(self, target_node_id):
        paths = []
        evidence_list = []
        
        # 1. Find Structural Sources (Articles/Clauses) that REGULATE this node
        structural_sources = []
        for src, _, edge_data in self.graph.in_edges(target_node_id, data=True):
            if edge_data.get("relation") == "REGULATES":
                structural_sources.append(src)
                
        # 2. Find Conditions / Procedures applied to this node
        for _, tgt, edge_data in self.graph.out_edges(target_node_id, data=True):
            relation = edge_data.get("relation")
            if relation in ["HAS_CONDITION", "HAS_PROCEDURE"]:
                tgt_node = self.nodes.get(tgt, {})
                
                # Build Path
                path_str = f"[{self.nodes.get(target_node_id, {}).get('name_vi', target_node_id)}] --{relation}--> [{tgt_node.get('name_vi', tgt)}]"
                
                # For structural prefix (if multiple sources, we just use the first for the path visualization)
                if structural_sources:
                    src_node = self.nodes.get(structural_sources[0], {})
                    src_name = src_node.get("name", structural_sources[0])
                    path_str = f"[{src_name}] --REGULATES--> " + path_str
                    
                paths.append(path_str)
                
                evidence_list.append({
                    "relation": relation,
                    "target_node": tgt_node,
                    "evidence_text": edge_data.get("evidence", ""),
                    "source_reference": edge_data.get("source_reference", "")
                })
                
        # Deduplicate evidence
        unique_evidence = []
        seen_ev = set()
        for ev in evidence_list:
            if ev["evidence_text"] not in seen_ev:
                unique_evidence.append(ev)
                seen_ev.add(ev["evidence_text"])
                
        # 3. Retrieve actual Structural Node contents (as requested, traversing through self.nodes instead of regex)
        structural_contents = []
        for src in structural_sources:
            node = self.nodes.get(src, {})
            content = node.get("content", "")
            title = node.get("title", "")
            name = node.get("name", "")
            full_text = f"{name}"
            if title: full_text += f": {title}"
            if content: full_text += f"\\n{content}"
            structural_contents.append({
                "id": src,
                "text": full_text
            })

        return paths, unique_evidence, structural_contents
