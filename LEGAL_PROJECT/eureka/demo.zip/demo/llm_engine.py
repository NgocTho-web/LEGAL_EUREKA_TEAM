import os
try:
    from openai import OpenAI
    client = OpenAI()
except Exception:
    client = None

def generate_answer(question, evidence_list, intent="condition_query"):
    if intent is None or not evidence_list:
        return "Xin lỗi, câu hỏi của bạn nằm ngoài phạm vi tư vấn hoặc dữ liệu Knowledge Graph hiện tại chưa có thông tin hỗ trợ cho trường hợp này."
        
    evidence_text = ""
    for idx, ev in enumerate(evidence_list):
        tgt = ev.get("target_node", {})
        evidence_text += f"{idx+1}. {tgt.get('name_vi', '')} (Tham chiếu: {ev.get('source_reference', '')})\n"
        
    prompt = f"""Bạn là trợ lý pháp luật Việt Nam.
Chỉ trả lời dựa trên evidence được cung cấp từ Knowledge Graph.
Không tự thêm thông tin bên ngoài.

Câu hỏi: {question}

Evidence từ Graph:
{evidence_text}

Hãy trả lời ngắn gọn, liệt kê các điều kiện/thủ tục và ghi rõ nguồn tham chiếu (Điều, Khoản).
"""

    if client and os.environ.get("OPENAI_API_KEY"):
        try:
            response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": prompt}],
                timeout=10
            )
            return response.choices[0].message.content
        except Exception as e:
            # Fallback on error
            pass

    # Robust Fallback Generation (No crash)
    answer = f"Dựa trên dữ liệu đồ thị, để thực hiện hành vi này bạn cần tuân thủ:\n\n{evidence_text}"
    return answer